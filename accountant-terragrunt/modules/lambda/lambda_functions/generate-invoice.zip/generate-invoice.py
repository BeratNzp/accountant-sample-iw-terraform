import boto3
import json
import os

def lambda_handler(event, context):
    try:
        dynamodb_client = boto3.client('dynamodb')
        dynamodb_table_name = os.environ['INVOICES_DYNAMODB_TABLE_NAME']
        
        s3_client = boto3.client('s3')
        s3_bucket_name = os.environ['INVOICES_BUCKET_NAME']

        event_body = json.loads(event['body'])
        invoice_id = event_body['id']
        invoice_amount = event_body['amount']

        # Save invoice to DynamoDB
        dynamodb_client.put_item(
            TableName=dynamodb_table_name,
            Item={
                'id': {'S': invoice_id},
                'amount': {'N': invoice_amount}
            }
        )

        # Create an PDF invoice
        invoice_file_name = f'{invoice_id}.pdf'
        invoice_file_path = f'/tmp/{invoice_file_name}'

        with open(invoice_file_path, 'w') as f:
            f.write(f'Invoice {invoice_id} for ${invoice_amount}')

        # Upload invoice to S3
        s3_client.upload_file(invoice_file_path, s3_bucket_name, 'invoices/' + invoice_file_name)

        return {
            'statusCode': 200,
            'body': json.dumps('Invoice generated successfully!')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error generating invoicex: {e}')
        }