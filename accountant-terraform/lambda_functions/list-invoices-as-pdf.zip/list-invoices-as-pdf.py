import boto3
import json
import os

def lambda_handler(event, context):
    try:
        s3_client = boto3.client('s3')
        bucket = s3_client.list_objects_v2(Bucket=os.environ['INVOICES_BUCKET_NAME'])

        invoice_list = []

        # List all objects in the bucket
        for obj in bucket.get('Contents', []):
            if obj['Key'].startswith('invoices') and obj['Key'].endswith('.pdf'):
                invoice = {
                    'name': obj['Key'].split('/')[1],
                    'presigned_url': s3_client.generate_presigned_url('get_object', Params={'Bucket': os.environ['INVOICES_BUCKET_NAME'], 'Key': obj['Key']}, ExpiresIn=300)
                }
                invoice_list.append(invoice)
        return {
            'statusCode': 200,
            'body': json.dumps(invoice_list)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(str(e))
        }