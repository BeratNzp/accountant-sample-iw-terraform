import boto3
import json
import os

def lambda_handler(event, context):
    try:
        dynamodb_client = boto3.client('dynamodb')
        response = dynamodb_client.scan(
            TableName=os.environ['INVOICES_DYNAMODB_TABLE_NAME']
        )
        return {
            'statusCode': 200,
            'body': json.dumps(response['Items'])
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }